
<?php $__env->startSection('pagetitle', 'Images'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xl-12 col-lg-12">
        <div class="card shadow mb-4">
            <!-- Card Body -->
            <div class="card-body">
                <div class="panel panel-default">
                    <?php if(count($images) == 0): ?>
                        <div class="panel-body text-center">
                            <h4>No Images Available.</h4>
                        </div>
                    <?php else: ?>
                    <div class="panel-body panel-body-with-table">
                        <div class="row">
                            <div class="card-group">
                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $multi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 mt-5">
                                        <div class="card">
                                            <img src="<?php echo e(asset($multi->image)); ?>" alt="">
                                        </div>
                                    </div>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <?php echo e($images->links("pagination::bootstrap-4")); ?>

                        
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\realproperty\real_property\resources\views/images/show.blade.php ENDPATH**/ ?>