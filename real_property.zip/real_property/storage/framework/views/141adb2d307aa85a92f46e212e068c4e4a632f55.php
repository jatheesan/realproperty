<div class="row">
    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('catagery') ? 'has-error' : ''); ?>">
            <label for="catagery" class="col-md-12 control-label">Catagery</label>
            <div class="col-md-12">
                <select class="form-control" id="catagery" name="catagery">
                    <option value="" style="display: none;" <?php echo e(old('catagery', optional($proparty)->catagery ?: '') == '' ? 'selected' : ''); ?> disabled selected>Select catagery here...</option>
                    <?php $__currentLoopData = ['for sale' => 'For Sale',
        'for let' => 'For Let',
        'shared accommodation' => 'Shared Accommodation']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('catagery', optional($proparty)->catagery) == $key ? 'selected' : ''); ?>>
                            <?php echo e($text); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
                <?php echo $errors->first('catagery', '<p class="help-block">:message</p>'); ?>

            </div>
        </div> 
    </div>
    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('type') ? 'has-error' : ''); ?>">
            <label for="type" class="col-md-12 control-label">Property Type</label>
            <div class="col-md-12">
                <select class="form-control" id="type" name="type">
                        <option value=""  <?php echo e(old('type', optional($proparty)->type ?: '') == '' ? 'selected' : ''); ?> selected>Select type here...</option>
                    <?php $__currentLoopData = $propertytypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $propertytype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('type', optional($proparty)->type) == $key ? 'selected' : ''); ?>>
                            <?php echo e($propertytype); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
                <?php echo $errors->first('type', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('age') ? 'has-error' : ''); ?>">
            <label for="age" class="col-md-12 control-label">Property Age</label>
            <div class="col-md-12">
                <select class="form-control" id="age" name="age">
                    <option value="" <?php echo e(old('age', optional($proparty)->age ?: '') == '' ? 'selected' : ''); ?> selected>Select age here...</option>
                    <?php $__currentLoopData = ['Mid 90' => 'Mid 90',
        'Mid 40' => 'Mid 40',
        'New' => 'New',
        'Newly build' => 'Newly build']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('age', optional($proparty)->age) == $key ? 'selected' : ''); ?>>
                            <?php echo e($text); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
                <?php echo $errors->first('age', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('minimum_term') ? 'has-error' : ''); ?>">
            <label for="minimum_term" class="col-md-12 control-label">Minimum Term</label>
            <div class="col-md-12">
                <select class="form-control" id="minimum_term" name="minimum_term">
                    <option value="" style= <?php echo e(old('minimum_term', optional($proparty)->minimum_term ?: '') == '' ? 'selected' : ''); ?> selected>Select minimum term here...</option>
                    <?php $__currentLoopData = ['1 month' => '1 Month',
        '3 month' => '2 Month',
        '1 year' => '1 Year',
        '2-5 year' => '2-5 Year',
        'long-term' => 'Long-term']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('minimum_term', optional($proparty)->minimum_term) == $key ? 'selected' : ''); ?>>
                            <?php echo e($text); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
                <?php echo $errors->first('minimum_term', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-12">
        <h4 class="color-b">Property Address</h4><hr color="orange"/>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('door_no') ? 'has-error' : ''); ?>">
            <label for="door_no" class="col-md-12 control-label">Door No</label>
            <div class="col-md-12">
                <input class="form-control" name="door_no" type="number" id="door_no" value="<?php echo e(old('door_no', optional($proparty)->door_no)); ?>" min="-2147483648" max="2147483647" placeholder="Enter door no here...">
                <?php echo $errors->first('door_no', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('door_name') ? 'has-error' : ''); ?>">
            <label for="door_name" class="col-md-12 control-label">Door Name</label>
            <div class="col-md-12">
                <input class="form-control" name="door_name" type="text" id="door_name" value="<?php echo e(old('door_name', optional($proparty)->door_name)); ?>" minlength="1" placeholder="Enter door name here...">
                <?php echo $errors->first('door_name', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('first_pastcode') ? 'has-error' : ''); ?>">
            <label for="first_pastcode" class="col-md-12 control-label">First Postcode</label>
            <div class="col-md-12">
                <input class="form-control" name="first_pastcode" type="text" id="first_pastcode" value="<?php echo e(old('first_pastcode', optional($proparty)->first_pastcode)); ?>" maxlength="5" placeholder="Enter first pastcode here...">
                <?php echo $errors->first('first_pastcode', '<p class="help-block">:message</p>'); ?>

            </div>
        </div> 
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('second_pastcode') ? 'has-error' : ''); ?>">
            <label for="second_pastcode" class="col-md-12 control-label">Second Postcode</label>
            <div class="col-md-12">
                <input class="form-control" name="second_pastcode" type="text" id="second_pastcode" value="<?php echo e(old('second_pastcode', optional($proparty)->second_pastcode)); ?>" maxlength="5" placeholder="Enter second pastcode here...">
                <?php echo $errors->first('second_pastcode', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('street_name') ? 'has-error' : ''); ?>">
            <label for="street_name" class="col-md-12 control-label">Street Name</label>
            <div class="col-md-12">
                <input class="form-control" name="street_name" type="text" id="street_name" value="<?php echo e(old('street_name', optional($proparty)->street_name)); ?>" placeholder="Enter street name here...">
                <?php echo $errors->first('street_name', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('second_street_name') ? 'has-error' : ''); ?>">
            <label for="second_street_name" class="col-md-12 control-label">Second Street Name</label>
            <div class="col-md-12">
                <input class="form-control" name="second_street_name" type="text" id="second_street_name" value="<?php echo e(old('second_street_name', optional($proparty)->second_street_name)); ?>" placeholder="Enter second street name here...">
                <?php echo $errors->first('second_street_name', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group <?php echo e($errors->has('post_town') ? 'has-error' : ''); ?>">
                    <label for="post_town" class="col-md-12 control-label">Post Town</label>
                    <div class="col-md-12">
                        <input class="form-control" name="post_town" type="text" id="post_town"
                            value="<?php echo e(old('post_town', optional($proparty)->post_town)); ?>" minlength="1"
                            placeholder="Enter post town here...">
                        <?php echo $errors->first('post_town', '<p class="help-block">:message</p>'); ?>

                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group <?php echo e($errors->has('post_city') ? 'has-error' : ''); ?>">
                    <label for="post_city" class="col-md-12 control-label">Post City</label>
                    <div class="col-md-12">
                        <input class="form-control" name="post_city" type="text" id="post_city" value="<?php echo e(old('post_city', optional($proparty)->post_city)); ?>" minlength="1" placeholder="Enter post city here...">
                        <?php echo $errors->first('post_city', '<p class="help-block">:message</p>'); ?>

                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group <?php echo e($errors->has('post_country') ? 'has-error' : ''); ?>">
                    <label for="post_country" class="col-md-12 control-label">Post Country</label>
                    <div class="col-md-12">
                        <input class="form-control" name="post_country" type="text" id="post_country" value="<?php echo e(old('post_country', optional($proparty)->post_country)); ?>" minlength="1" placeholder="Enter post country here...">
                        <?php echo $errors->first('post_country', '<p class="help-block">:message</p>'); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('display_address') ? 'has-error' : ''); ?>">
            <label for="display_address" class="col-md-12 control-label">Display Address</label>
            <div class="col-md-12">
                <textarea class="form-control" name="display_address" cols="40" rows="8" id="display_address" minlength="1" placeholder="Enter display address here..."><?php echo e(old('display_address', optional($proparty)->display_address)); ?></textarea>
                <?php echo $errors->first('display_address', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-12">
        <h4 class="color-b">Property Condition & Details</h4><hr color="orange"/>
    </div>
    <div class="col-md-12">
        <div class="form-group <?php echo e($errors->has('condition_of_property') ? 'has-error' : ''); ?>">
            <label for="condition_of_property" class="col-md-12 control-label">Condition of Property</label>
            <div class="col-md-12">
                <select class="form-control" id="condition_of_property" name="condition_of_property">
                    <option value="" <?php echo e(old('condition_of_property', optional($proparty)->condition_of_property ?: '') == '' ? 'selected' : ''); ?> selected>Select condition of property here...</option>   
                    <?php $__currentLoopData = ['Require Painting' => 'Require Painting',
        'Fully Decorated' => 'Fully Decorated']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('condition_of_property', optional($proparty)->condition_of_property) == $key ? 'selected' : ''); ?>>
                            <?php echo e($text); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
                <?php echo $errors->first('condition_of_property', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('furnished_property') ? 'has-error' : ''); ?>">
            <label for="furnished_property" class="col-md-12 control-label">Furnished Property</label>
            <div class="col-md-12">
                <label for="furnished_property_bed_and_sofa_included" class="checkbox-inline">
                    <input id="furnished_property_bed_and_sofa_included" class="required" name="furnished_property[]" type="checkbox" value="Bed and sofa included" <?php echo e(in_array('Bed and sofa included', old('furnished_property', optional($proparty)->furnished_property) ?: []) ? 'checked' : ''); ?>>
                    Bed and sofa included
                </label>
                <label for="furnished_property_kitchen_items_are_included" class="checkbox-inline">
                    <input id="furnished_property_kitchen_items_are_included" class="required" name="furnished_property[]" type="checkbox" value="Kitchen Items are included" <?php echo e(in_array('Kitchen Items are included', old('furnished_property', optional($proparty)->furnished_property) ?: []) ? 'checked' : ''); ?>>
                    Kitchen Items are included
                </label>

                <?php echo $errors->first('furnished_property', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('accessability') ? 'has-error' : ''); ?>">
            <label for="accessability" class="col-md-12 control-label">Accessability</label>
            <div class="col-md-10">
                <label for="accessability_ground_floor_access" class="checkbox-inline">
                    <input id="accessability_ground_floor_access" class="required" name="accessability[]" type="checkbox" value="Ground floor Access" <?php echo e(in_array('Ground floor Access', old('accessability', optional($proparty)->accessability) ?: []) ? 'checked' : ''); ?>>
                    Ground floor Access
                </label>
                <label for="accessability_seperate_enterance" class="checkbox-inline">
                    <input id="accessability_seperate_enterance" class="required" name="accessability[]" type="checkbox" value="Seperate Enterance" <?php echo e(in_array('Seperate Enterance', old('accessability', optional($proparty)->accessability) ?: []) ? 'checked' : ''); ?>>
                    Seperate Enterance
                </label>
                <label for="accessability_shared_corridor" class="checkbox-inline">
                    <input id="accessability_shared_corridor" class="required" name="accessability[]" type="checkbox" value="Shared corridor" <?php echo e(in_array('Shared corridor', old('accessability', optional($proparty)->accessability) ?: []) ? 'checked' : ''); ?>>
                    Shared corridor
                </label>

                <?php echo $errors->first('accessability', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('heating_type') ? 'has-error' : ''); ?>">
            <label for="heating_type" class="col-md-12 control-label">Heating Type</label>
            <div class="col-md-12">
                <label for="heating_type_central" class="checkbox-inline">
                    <input id="heating_type_central" class="required" name="heating_type[]" type="checkbox" value="Central" <?php echo e(in_array('Central', old('heating_type', optional($proparty)->heating_type) ?: []) ? 'checked' : ''); ?>>
                    Central
                </label>
                <label for="heating_type_gas" class="checkbox-inline">
                    <input id="heating_type_gas" class="required" name="heating_type[]" type="checkbox" value="Gas" <?php echo e(in_array('Gas', old('heating_type', optional($proparty)->heating_type) ?: []) ? 'checked' : ''); ?>>
                    Gas
                </label>
                <label for="heating_type_combi_boilder" class="checkbox-inline">
                    <input id="heating_type_combi_boilder" class="required" name="heating_type[]" type="checkbox" value="Combi Boilder" <?php echo e(in_array('Combi Boilder', old('heating_type', optional($proparty)->heating_type) ?: []) ? 'checked' : ''); ?>>
                    Combi Boilder
                </label>

                <?php echo $errors->first('heating_type', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('is_burglar_alarm') ? 'has-error' : ''); ?>">
            <label for="is_burglar_alarm" class="col-md-12 control-label">Is Burglar Alarm</label>
            <div class="col-md-12">
                <label for="is_burglar_alarm_1" class="checkbox-inline">
                    <input id="is_burglar_alarm_1" class="" name="is_burglar_alarm" type="checkbox" value="1" <?php echo e(old('is_burglar_alarm', optional($proparty)->is_burglar_alarm) == '1' ? 'checked' : ''); ?>>
                    Yes
                </label>

                <?php echo $errors->first('is_burglar_alarm', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('is_cctv') ? 'has-error' : ''); ?>">
            <label for="is_cctv" class="col-md-12 control-label">Is CCTV</label>
            <div class="col-md-12">
                <label for="is_cctv_1" class="checkbox-inline">
                    <input id="is_cctv_1" class="" name="is_cctv" type="checkbox" value="1" <?php echo e(old('is_cctv', optional($proparty)->is_cctv) == '1' ? 'checked' : ''); ?>>
                    Yes
                </label>

                <?php echo $errors->first('is_cctv', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('bill') ? 'has-error' : ''); ?>">
            <label for="bill" class="col-md-12 control-label">Bill</label>
            <div class="col-md-12">
                <select class="form-control" id="bill" name="bill">
                <option value="" <?php echo e(old('bill', optional($proparty)->bill ?: '') == '' ? 'selected' : ''); ?> selected>Select bill here...</option>   
                    <?php $__currentLoopData = ['Included' => 'Included',
        'Excluded' => 'Excluded',
        'Shared' => 'Shared']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('bill', optional($proparty)->bill) == $key ? 'selected' : ''); ?>>
                            <?php echo e($text); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
                <?php echo $errors->first('bill', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('enquiry_contact') ? 'has-error' : ''); ?>">
            <label for="enquiry_contact" class="col-md-12 control-label">Property Enquiry Contact</label>
            <div class="col-md-12">
                <input class="form-control" name="enquiry_contact" type="text" id="enquiry_contact" value="<?php echo e(old('enquiry_contact', optional($proparty)->enquiry_contact)); ?>" minlength="1" placeholder="Enter property enquiry contact here...">
                <?php echo $errors->first('enquiry_contact', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('enquiry_email') ? 'has-error' : ''); ?>">
            <label for="enquiry_email" class="col-md-12 control-label">Property Enquiry Email</label>
            <div class="col-md-12">
                <input class="form-control" name="enquiry_email" type="email" id="enquiry_email" value="<?php echo e(old('enquiry_email', optional($proparty)->enquiry_email)); ?>" placeholder="Enter property enquiry contact here...">
                <?php echo $errors->first('enquiry_email', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
             
        <div class="form-group table-responsive">
            <label for="sale_condition" class="col-md-10 control-label">Sale Condition</label><a class="btn-sm btn-success" onclick="addsale();"><i class="fa fa-plus"></i></a>
            <table id="faqs" class="table table-borderless">
                <tbody>
                    <?php if( isset(optional($proparty)->sale_condition)): ?>
                        <?php $__currentLoopData = optional($proparty)->sale_condition; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="faqs-row">
                            <td>
                                <input class="form-control" name="sale_condition[]" type="text" id="sale_condition" value="<?php echo e($key); ?>" placeholder="Enter sale condition here...">
                                <?php echo $errors->first('sale_condition', '<p class="help-block">:message</p>'); ?>

                            </td>
                            <td>
                                <a href="javascript:void(0)" class="btn-sm btn-danger" onclick="SomeDeleteRowFunction()"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td>
                                <input class="form-control" name="sale_condition[]" type="text" id="sale_condition" value="<?php echo e(old('sale_condition')); ?>" placeholder="Enter sale condition here...">
                                <?php echo $errors->first('sale_condition', '<p class="help-block">:message</p>'); ?>

                            </td>
                            <td>
                                <a href="javascript:void(0)" class="btn-sm btn-danger"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-md-6">
        
        <div class="form-group table-responsive">
            <label for="rent_condition" class="col-md-10 control-label">Rent Condition</label><a class="btn-sm btn-success" onclick="addrent();"><i class="fa fa-plus"></i></a>
            <table id="faqr" class="table table-borderless">
                <tbody>
                    <?php if( isset(optional($proparty)->rent_condition)): ?>
                        <?php $__currentLoopData = optional($proparty)->rent_condition; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <input class="form-control" name="rent_condition[]" type="text" id="rent_condition" value="<?php echo e($key); ?>" placeholder="Enter rent condition here...">
                                <?php echo $errors->first('rent_condition', '<p class="help-block">:message</p>'); ?>

                            </td>
                            <td>
                                <a href="javascript:void(0)" class="btn-sm btn-danger" onclick="SomeDeleteRowFunction()"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td>
                                <input class="form-control" name="rent_condition[]" type="text" id="rent_condition" value="<?php echo e(old('rent_condition')); ?>" placeholder="Enter rent condition here...">
                                <?php echo $errors->first('rent_condition', '<p class="help-block">:message</p>'); ?>

                            </td>
                            <td>
                                <a href="javascript:void(0)" class="btn-sm btn-danger"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-md-12">
        <h4 class="color-b">Internal External Structure</h4><hr color="orange"/>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('no_of_bedrooms') ? 'has-error' : ''); ?>">
            <label for="no_of_bedrooms" class="col-md-12 control-label">No of Bedrooms</label>
            <div class="col-md-12">
                <input class="form-control" name="no_of_bedrooms" type="number" id="no_of_bedrooms" value="<?php echo e(old('no_of_bedrooms', optional($proparty)->no_of_bedrooms)); ?>" min="-2147483648" max="2147483647" placeholder="Enter no of bedrooms here...">
                <?php echo $errors->first('no_of_bedrooms', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('no_of_bathrooms') ? 'has-error' : ''); ?>">
            <label for="no_of_bathrooms" class="col-md-12 control-label">No of Bathrooms</label>
            <div class="col-md-12">
                <input class="form-control" name="no_of_bathrooms" type="number" id="no_of_bathrooms" value="<?php echo e(old('no_of_bathrooms', optional($proparty)->no_of_bathrooms)); ?>" min="-2147483648" max="2147483647" placeholder="Enter no of bathrooms here...">
                <?php echo $errors->first('no_of_bathrooms', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group <?php echo e($errors->has('no_of_halls') ? 'has-error' : ''); ?>">
            <label for="no_of_halls" class="col-md-12 control-label">No of Halls</label>
            <div class="col-md-12">
                <input class="form-control" name="no_of_halls" type="number" id="no_of_halls" value="<?php echo e(old('no_of_halls', optional($proparty)->no_of_halls)); ?>" min="-2147483648" max="2147483647" placeholder="Enter no of halls here...">
                <?php echo $errors->first('no_of_halls', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group <?php echo e($errors->has('no_of_reseptions') ? 'has-error' : ''); ?>">
            <label for="no_of_reseptions" class="col-md-12 control-label">No of Reseptions</label>
            <div class="col-md-12">
                <input class="form-control" name="no_of_reseptions" type="number" id="no_of_reseptions" value="<?php echo e(old('no_of_reseptions', optional($proparty)->no_of_reseptions)); ?>" min="-2147483648" max="2147483647" placeholder="Enter no of reseptions here...">
                <?php echo $errors->first('no_of_reseptions', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group <?php echo e($errors->has('floors') ? 'has-error' : ''); ?>">
            <label for="floors" class="col-md-12 control-label">Floors</label>
            <div class="col-md-12">
                <input class="form-control" name="floors" type="number" id="floors" value="<?php echo e(old('floors', optional($proparty)->floors)); ?>" min="-2147483648" max="2147483647" placeholder="Enter floors here...">
                <?php echo $errors->first('floors', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('parking') ? 'has-error' : ''); ?>">
            <label for="parking" class="col-md-12 control-label">Parking</label>
            <div class="col-md-12">
                <label for="parking_allocated" class="checkbox-inline">
                    <input id="parking_allocated" class="required" name="parking[]" type="checkbox" value="Allocated" <?php echo e(in_array('Allocated', old('parking', optional($proparty)->parking) ?: []) ? 'checked' : ''); ?>>
                    Allocated
                </label>
                <label for="parking_garage" class="checkbox-inline">
                    <input id="parking_garage" class="required" name="parking[]" type="checkbox" value="Garage" <?php echo e(in_array('Garage', old('parking', optional($proparty)->parking) ?: []) ? 'checked' : ''); ?>>
                    Garage
                </label>
                <label for="parking_driveway" class="checkbox-inline">
                    <input id="parking_driveway" class="required" name="parking[]" type="checkbox" value="Driveway" <?php echo e(in_array('Driveway', old('parking', optional($proparty)->parking) ?: []) ? 'checked' : ''); ?>>
                    Driveway
                </label>
                <label for="parking_gated" class="checkbox-inline">
                    <input id="parking_gated" class="required" name="parking[]" type="checkbox" value="Gated" <?php echo e(in_array('Gated', old('parking', optional($proparty)->parking) ?: []) ? 'checked' : ''); ?>>
                    Gated
                </label>
                <label for="parking_off_street" class="checkbox-inline">
                    <input id="parking_off_street" class="required" name="parking[]" type="checkbox" value="Off Street" <?php echo e(in_array('Off Street', old('parking', optional($proparty)->parking) ?: []) ? 'checked' : ''); ?>>
                    Off Street
                </label>
                <label for="parking_on_street" class="checkbox-inline">
                    <input id="parking_on_street" class="required" name="parking[]" type="checkbox" value="On Street" <?php echo e(in_array('On Street', old('parking', optional($proparty)->parking) ?: []) ? 'checked' : ''); ?>>
                    On Street
                </label>

                <?php echo $errors->first('parking', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('garden') ? 'has-error' : ''); ?>">
            <label for="garden" class="col-md-12 control-label">Garden</label>
            <div class="col-md-12">
                <label for="garden_back_garden" class="checkbox-inline">
                    <input id="garden_back_garden" class="required" name="garden[]" type="checkbox" value="Back Garden" <?php echo e(in_array('Back Garden', old('garden', optional($proparty)->garden) ?: []) ? 'checked' : ''); ?>>
                    Back Garden
                </label>
                <label for="garden_front_garden" class="checkbox-inline">
                    <input id="garden_front_garden" class="required" name="garden[]" type="checkbox" value="Front Garden" <?php echo e(in_array('Front Garden', old('garden', optional($proparty)->garden) ?: []) ? 'checked' : ''); ?>>
                    Front Garden
                </label>
                <label for="garden_communal_garden" class="checkbox-inline">
                    <input id="garden_communal_garden" class="required" name="garden[]" type="checkbox" value="Communal Garden" <?php echo e(in_array('Communal Garden', old('garden', optional($proparty)->garden) ?: []) ? 'checked' : ''); ?>>
                    Communal Garden
                </label>
                <label for="garden_terrace" class="checkbox-inline">
                    <input id="garden_terrace" class="required" name="garden[]" type="checkbox" value="Terrace" <?php echo e(in_array('Terrace', old('garden', optional($proparty)->garden) ?: []) ? 'checked' : ''); ?>>
                    Terrace
                </label>

                <?php echo $errors->first('garden', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group <?php echo e($errors->has('internal_area') ? 'has-error' : ''); ?>">
            <label for="internal_area" class="col-md-12 control-label">Internal Area</label>
            <div class="col-md-12">
                <input class="form-control" name="internal_area" type="text" id="internal_area" value="<?php echo e(old('internal_area', optional($proparty)->internal_area)); ?>" minlength="1" placeholder="Enter measurement of internal area here...">
                <?php echo $errors->first('internal_area', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group <?php echo e($errors->has('land_area') ? 'has-error' : ''); ?>">
            <label for="land_area" class="col-md-12 control-label">Land Area</label>
            <div class="col-md-12">
                <input class="form-control" name="land_area" type="text" id="land_area" value="<?php echo e(old('land_area', optional($proparty)->land_area)); ?>" minlength="1" placeholder="Enter measurement of land area here...">
                <?php echo $errors->first('land_area', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group <?php echo e($errors->has('area_unit') ? 'has-error' : ''); ?>">
            <label for="area_unit" class="col-md-12 control-label">Area Unit</label>
            <div class="col-md-12">
                <select class="form-control" id="area_unit" name="area_unit">
                        <option value="" <?php echo e(old('area_unit', optional($proparty)->area_unit ?: '') == '' ? 'selected' : ''); ?> selected>Enter area unit here...</option>
                    <?php $__currentLoopData = ['sq m' => 'sq m',
        'sq cm' => 'sq cm',
        'sq mm' => 'sq mm',
        'sq ft' => 'sq ft',
        'sq inch' => 'sq inch']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('area_unit', optional($proparty)->area_unit) == $key ? 'selected' : ''); ?>>
                            <?php echo e($text); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
                <?php echo $errors->first('area_unit', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-12">
        <h4 class="color-b">Price & Terms</h4><hr color="orange"/>
    </div>
    <div class="col-md-10">
        <div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
            <label for="price" class="col-md-12 control-label">Price</label>
            <div class="col-md-12">
                <input class="form-control" name="price" type="number" id="price" value="<?php echo e(old('price', optional($proparty)->price)); ?>" min="-2147483648" max="2147483647" placeholder="Enter price here...">
                <?php echo $errors->first('price', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group <?php echo e($errors->has('price_flag') ? 'has-error' : ''); ?>">
            <label for="price_flag" class="col-md-12 control-label">Price Flag</label>
            <div class="col-md-12">
                <label for="price_flag_1" class="checkbox-inline">
                    <input id="price_flag_1" class="" name="price_flag" type="checkbox" value="1" <?php echo e(old('price_flag', optional($proparty)->price_flag) == '1' ? 'checked' : ''); ?>>
                    Yes
                </label>

                <?php echo $errors->first('price_flag', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    
    <div class="col-md-5">
        <div class="form-group <?php echo e($errors->has('rent_frequency') ? 'has-error' : ''); ?>">
            <label for="rent_frequency" class="col-md-12 control-label">Rent Frequency</label>
            <div class="col-md-12">
                <select class="form-control" id="rent_frequency" name="rent_frequency">
                    <option value="" style="display: none;" <?php echo e(old('rent_frequency', optional($proparty)->rent_frequency ?: '') == '' ? 'selected' : ''); ?> disabled selected>Select rent frequency here...</option>    
                    <?php $__currentLoopData = ['Monthly' => 'Monthly',
        'Quarter' => 'Quarter',
        'Half' => 'Half',
        'Annual' => 'Annual']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('rent_frequency', optional($proparty)->rent_frequency) == $key ? 'selected' : ''); ?>>
                            <?php echo e($text); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
                <?php echo $errors->first('rent_frequency', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div class="form-group <?php echo e($errors->has('deposite') ? 'has-error' : ''); ?>">
            <label for="deposite" class="col-md-12 control-label">Deposite Minimum</label>
            <div class="col-md-12">
                <input class="form-control" name="deposite" type="number" id="deposite" value="<?php echo e(old('deposite', optional($proparty)->deposite)); ?>" min="-2147483648" max="2147483647" placeholder="Enter deposite here...">
                <?php echo $errors->first('deposite', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group <?php echo e($errors->has('deposite_flag') ? 'has-error' : ''); ?>">
            <label for="deposite_flag" class="col-md-12 control-label">Deposite Flag</label>
            <div class="col-md-12">
                <label for="deposite_flag_1" class="checkbox-inline">
                    <input id="deposite_flag_1" class="" name="deposite_flag" type="checkbox" value="1" <?php echo e(old('deposite_flag', optional($proparty)->deposite_flag) == '1' ? 'checked' : ''); ?>>
                    Yes
                </label>

                <?php echo $errors->first('deposite_flag', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div class="form-group <?php echo e($errors->has('admin_fee_max') ? 'has-error' : ''); ?>">
            <label for="admin_fee_max" class="col-md-12 control-label">Admin Fee Maxmimum</label>
            <div class="col-md-12">
                <input class="form-control" name="admin_fee_max" type="number" id="admin_fee_max" value="<?php echo e(old('admin_fee_max', optional($proparty)->admin_fee_max)); ?>" min="-2147483648" max="2147483647" placeholder="Enter admin fee maximum here...">
                <?php echo $errors->first('admin_fee_max', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div class="form-group <?php echo e($errors->has('admin_fee_exe') ? 'has-error' : ''); ?>">
            <label for="admin_fee_exe" class="col-md-12 control-label">Admin Fee Exemption</label>
            <div class="col-md-12">
                <input class="form-control" name="admin_fee_exe" type="number" id="admin_fee_exe" value="<?php echo e(old('admin_fee_exe', optional($proparty)->admin_fee_exe)); ?>" min="-2147483648" max="2147483647" placeholder="Enter admin fee exemption here...">
                <?php echo $errors->first('admin_fee_exe', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group <?php echo e($errors->has('admin_fee_flag') ? 'has-error' : ''); ?>">
            <label for="admin_fee_flag" class="col-md-12 control-label">Admin Fee Flag</label>
            <div class="col-md-12">
                <label for="admin_fee_flag_1" class="checkbox-inline">
                    <input id="admin_fee_flag_1" class="" name="admin_fee_flag" type="checkbox" value="1" <?php echo e(old('admin_fee_flag', optional($proparty)->admin_fee_flag) == '1' ? 'checked' : ''); ?>>
                    Yes
                </label>

                <?php echo $errors->first('admin_fee_flag', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-12">
        <h4 class="color-b">Other Terms</h4><hr color="orange"/>
    </div>
    <div class="col-md-4">
        <div class="form-group <?php echo e($errors->has('date_intake') ? 'has-error' : ''); ?>">
            <label for="date_intake" class="col-md-12 control-label">Date Intake</label>
            <div class="col-md-12">
                <input class="form-control" name="date_intake" type="date" id="date_intake" value="<?php echo e(old('date_intake', optional($proparty)->date_intake)); ?>" placeholder="Enter date intake here...">
                <?php echo $errors->first('date_intake', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group <?php echo e($errors->has('date_published') ? 'has-error' : ''); ?>">
            <label for="date_published" class="col-md-12 control-label">Date Published</label>
            <div class="col-md-12">
                <input class="form-control" name="date_published" type="date" id="date_published" value="<?php echo e(old('date_published', optional($proparty)->date_published)); ?>" placeholder="Enter date published here...">
                <?php echo $errors->first('date_published', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group <?php echo e($errors->has('date_revoked') ? 'has-error' : ''); ?>">
            <label for="date_revoked" class="col-md-12 control-label">Date Revoked</label>
            <div class="col-md-12">
                <input class="form-control" name="date_revoked" type="date" id="date_revoked" value="<?php echo e(old('date_revoked', optional($proparty)->date_revoked)); ?>" placeholder="Enter date revoked here...">
                <?php echo $errors->first('date_revoked', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div class="form-group <?php echo e($errors->has('property_details') ? 'has-error' : ''); ?>">
            <label for="property_details" class="col-md-12 control-label">Property Details</label>
            <div class="col-md-12">
                <textarea class="form-control" name="property_details" cols="50" rows="5" id="property_details" minlength="1" placeholder="Enter property details here..."><?php echo e(old('property_details', optional($proparty)->property_details)); ?></textarea>
                <?php echo $errors->first('property_details', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        
    </div>
    <div class="col-md-5">
        
        <div class="form-group table-responsive">
            <label for="further_details" class="col-md-10 control-label">Further Details</label><a class="btn-sm btn-success" onclick="addprodis();"><i class="fa fa-plus"></i></a>
            <table id="faqpdis" class="table table-borderless">
                <tbody>
                    <?php if( isset(optional($proparty)->further_details)): ?>
                        <?php $__currentLoopData = optional($proparty)->further_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <input class="form-control" name="further_details[]" type="text" id="further_details" value="<?php echo e($key); ?>" placeholder="Enter further details here...">
                                <?php echo $errors->first('further_details', '<p class="help-block">:message</p>'); ?>

                            </td>
                            <td>
                                <a href="javascript:void(0)" class="btn-sm btn-danger" onclick="SomeDeleteRowFunction()"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td>
                                <input class="form-control" name="further_details[]" type="text" id="further_details" value="<?php echo e(old('further_details')); ?>" placeholder="Enter further details here...">
                                <?php echo $errors->first('further_details', '<p class="help-block">:message</p>'); ?>

                            </td>
                            <td>
                                <a href="javascript:void(0)" class="btn-sm btn-danger"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group <?php echo e($errors->has('property_details_display') ? 'has-error' : ''); ?>">
            <label for="property_details_display" class="col-md-12 control-label">Is Display Property Details</label>
            <div class="col-md-12">
                <label for="property_details_display_1" class="checkbox-inline">
                    <input id="property_details_display_1" class="" name="property_details_display" type="checkbox" value="1" <?php echo e(old('property_details_display', optional($proparty)->property_details_display) == '1' ? 'checked' : ''); ?>>
                    Yes
                </label>

                <?php echo $errors->first('property_details_display', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="form-group <?php echo e($errors->has('owner') ? 'has-error' : ''); ?>">
            <label for="owner" class="col-md-12 control-label">Owner</label>
            <div class="col-md-12">
                <select class="form-control" id="owner" name="owner">
                        <option value="" style="display: none;" <?php echo e(old('owner', optional($proparty)->owner ?: '') == '' ? 'selected' : ''); ?> disabled selected>Select owner here...</option>
                    <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $own): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('owner', optional($proparty)->owner) == $key ? 'selected' : ''); ?>>
                            <?php echo e($own); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
                <?php echo $errors->first('owner', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('is_complete') ? 'has-error' : ''); ?>">
            <label for="is_complete" class="col-md-12 control-label">Is Complete</label>
            <div class="col-md-12">
                <label for="is_complete-1" class="checkbox-inline">
                    <input id="is_complete_1" class="" name="is_complete" type="checkbox" value="1" <?php echo e(old('is_complete', optional($proparty)->is_complete) == '1' ? 'checked' : ''); ?>>
                    Yes
                </label>

                <?php echo $errors->first('is_complete', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('is_publish') ? 'has-error' : ''); ?>">
            <label for="is_publish" class="col-md-12 control-label">Is Publish</label>
            <div class="col-md-12">
                <label for="is_publish_1" class="checkbox-inline">
                    <input id="is_publish_1" class="" name="is_publish" type="checkbox" value="1" <?php echo e(old('is_publish', optional($proparty)->is_publish) == '1' ? 'checked' : ''); ?>>
                    Yes
                </label>

                <?php echo $errors->first('is_publish', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div> 
    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('is_sold') ? 'has-error' : ''); ?>">
            <label for="is_sold" class="col-md-12 control-label">Is Sold</label>
            <div class="col-md-12">
                <label for="is_sold_1" class="checkbox-inline">
                    <input id="is_sold_1" class="" name="is_sold" type="checkbox" value="1" <?php echo e(old('is_sold', optional($proparty)->is_sold) == '1' ? 'checked' : ''); ?>>
                    Yes
                </label>

                <?php echo $errors->first('is_sold', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>    
</div>




<script>
    var faqs_row = 0;
    function addsale(){
        html = '<tr id="faqs-row' + faqs_row + '">';
        html += '<td><input class="form-control" name="sale_condition[]" type="text" id="sale_condition" placeholder="Enter sale condition here..."></td>';
        html += '<td><a href="javascript:void(0)" class="btn-sm btn-danger" onclick="$(\'#faqs-row' + faqs_row + '\').remove();"><i class="fa fa-trash"></i></a></td>';

        html += '</tr>';
    $('#faqs tbody').append(html);

    faqs_row++;
    }
</script>

<script>
    var faqr_row = 0;
    function addrent(){
        html = '<tr id="faqr-row' + faqr_row + '">';
        html += '<td><input class="form-control" name="rent_condition[]" type="text" id="rent_condition" placeholder="Enter Rent condition here..."></td>';
        html += '<td><a href="javascript:void(0)" class="btn-sm btn-danger" onclick="$(\'#faqr-row' + faqr_row + '\').remove();"><i class="fa fa-trash"></i></a></td>';

        html += '</tr>';
    $('#faqr tbody').append(html);

    faqr_row++;
    }
</script>

<script>
    var faqpd_row = 0;
    function addprode(){
        html = '<tr id="faqpd-row' + faqpd_row + '">';
        html += '<td><input class="form-control" name="property_details[]" type="text" id="property_details" placeholder="Enter property details here..."></td>';
        html += '<td><a href="javascript:void(0)" class="btn-sm btn-danger" onclick="$(\'#faqpd-row' + faqpd_row + '\').remove();"><i class="fa fa-trash"></i></a></td>';

        html += '</tr>';
    $('#faqpd tbody').append(html);

    faqpd_row++;
    }
</script>

<script>
    var faqpdis_row = 0;
    function addprodis(){
        html = '<tr id="faqpdis-row' + faqpdis_row + '">';
        html += '<td><input class="form-control" name="further_details[]" type="text" id="further_details" placeholder="Enter further details here..."></td>';
        html += '<td><a href="javascript:void(0)" class="btn-sm btn-danger" onclick="$(\'#faqpdis-row' + faqpdis_row + '\').remove();"><i class="fa fa-trash"></i></a></td>';

        html += '</tr>';
    $('#faqpdis tbody').append(html);

    faqpdis_row++;
    }
</script>

<script>
function SomeDeleteRowFunction() {
    $('table').on('click', 'a', function(e){
        $(this).closest('tr').remove()
    })
}
</script>



<?php /**PATH C:\xampp\htdocs\laravel\realproperty\real_property\resources\views/proparties/form.blade.php ENDPATH**/ ?>