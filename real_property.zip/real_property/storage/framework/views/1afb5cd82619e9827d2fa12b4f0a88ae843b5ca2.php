<?php $__env->startSection('pagetitle', 'Properties'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xl-12 col-lg-12">
        <div class="float-right">
        <form method="POST" action="<?php echo route('proparties.proparty.destroy', $proparty->id); ?>"
            accept-charset="UTF-8">
            <input name="_method" value="DELETE" type="hidden">
            <?php echo e(csrf_field()); ?>

            <div class="btn-group btn-group-sm" role="group">
                <a href="<?php echo e(route('proparties.proparty.index')); ?>" class="btn btn-primary"
                    title="Show All Proparty Type">
                    <span class="fa fa-list" aria-hidden="true"></span>
                </a>

                <a href="<?php echo e(route('proparties.proparty.create')); ?>" class="btn btn-success"
                    title="Create New Proparty Type">
                    <span class="fa fa-plus" aria-hidden="true"></span>
                </a>

                <a href="<?php echo e(route('proparties.proparty.edit', $proparty->id )); ?>" class="btn btn-primary"
                    title="Edit Proparty Type">
                    <span class="fa fa-pencil-alt" aria-hidden="true"></span>
                </a>

                <button type="submit" class="btn btn-danger" title="Delete Proparty" onclick="return confirm(&quot;Click Ok to delete Proparty.?&quot;)">
                        <span class="fa fa-trash" aria-hidden="true"></span>
                    </button>
            </div>
        </form>
        </div>
    </div>
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <span class="float-left">
                    <h2 style="color:#ff9933;">
                        <?php echo e(isset($title) ? $title : 'Proparty'); ?>

                    </h2>
                </span>  
            </div>
            <!-- Card Body -->
            <div class="card-body">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <tr>
                                        <th colspan="2" style="color:#FF4500"><h1>Property Details</h1></th>
                                    </tr>
                                    <tr>
                                        <th>Catagery :</th>
                                        <td><?php echo e($proparty->catagery); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Property Type :</th>
                                        <td><?php echo e(optional($proparty->propertytype)->type_name); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Property Age :</th>
                                        <td><?php echo e($proparty->age); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Minimum Term :</th>
                                        <td><?php echo e($proparty->minimum_term); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Door No :</th>
                                        <td><?php echo e($proparty->door_no); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Door Name :</th>
                                        <td><?php echo e($proparty->door_name); ?></td>
                                    </tr>
                                    <tr>
                                        <th>First Postcode :</th>
                                        <td><?php echo e($proparty->first_pastcode); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Second Postcode :</th>
                                        <td><?php echo e($proparty->second_pastcode); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Street Name :</th>
                                        <td><?php echo e($proparty->street_name); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Second Street Name :</th>
                                        <td><?php echo e($proparty->second_street_name); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Post Town :</th>
                                        <td><?php echo e($proparty->post_town); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Post City :</th>
                                        <td><?php echo e($proparty->post_city); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Post Country :</th>
                                        <td><?php echo e($proparty->post_country); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Display Address :</th>
                                        <td><?php echo e($proparty->display_address); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Condition of Property :</th>
                                        <td><?php echo e($proparty->condition_of_property); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Furnished Property :</th>
                                        <td><?php echo e(implode(', ', $proparty->furnished_property)); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Accessability :</th>
                                        <td><?php echo e(implode(', ', $proparty->accessability)); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Heating Type :</th>
                                        <td><?php echo e(implode('; ', $proparty->heating_type)); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Is Burglar Alarm :</th>
                                        <td><?php echo e(($proparty->is_burglar_alarm) ? 'Yes' : 'No'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Is CCTV :</th>
                                        <td><?php echo e(($proparty->is_cctv) ? 'Yes' : 'No'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Bill :</th>
                                        <td><?php echo e($proparty->bill); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Property Enquiry Contact :</th>
                                        <td><?php echo e($proparty->enquiry_contact); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Property Enquiry Email :</th>
                                        <td><?php echo e($proparty->enquiry_email); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Sale Condition :</th>
                                        <td><?php echo e(implode(', ', $proparty->sale_condition)); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Rent Condition :</th>
                                        <td><?php echo e(implode(', ', $proparty->rent_condition)); ?></td>
                                    </tr>
                                    <tr>
                                        <th>NO of Bedrooms :</th>
                                        <td><?php echo e($proparty->no_of_bedrooms); ?></td>
                                    </tr>
                                    <tr>
                                        <th>NO of Bathrooms :</th>
                                        <td><?php echo e($proparty->no_of_bathrooms); ?></td>
                                    </tr>
                                    <tr>
                                        <th>NO of Halls :</th>
                                        <td><?php echo e($proparty->no_of_halls); ?></td>
                                    </tr>
                                    <tr>
                                        <th>NO of Reseptions :</th>
                                        <td><?php echo e($proparty->no_of_reseptions); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Floors :</th>
                                        <td><?php echo e($proparty->floors); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Parking :</th>
                                        <td><?php echo e(implode('& ', $proparty->parking)); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Garden :</th>
                                        <td><?php echo e(implode('& ', $proparty->garden)); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Internal Area :</th>
                                        <td><?php echo e($proparty->internal_area); ?><?php echo e($proparty->area_unit); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Land Area :</th>
                                        <td><?php echo e($proparty->land_area); ?><?php echo e($proparty->area_unit); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Price :</th>
                                        <td><?php echo e($proparty->price); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Price Flag :</th>
                                        <td><?php echo e(($proparty->price_flag) ? 'Yes' : 'No'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Rent Frequency :</th>
                                        <td><?php echo e($proparty->rent_frequency); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Deposite Minimum :</th>
                                        <td><?php echo e($proparty->deposite); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Deposite Flag :</th>
                                        <td><?php echo e(($proparty->deposite_flag) ? 'Yes' : 'No'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Admin Fee Maxmimum :</th>
                                        <td><?php echo e($proparty->admin_fee_max); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Admin Fee Exemption :</th>
                                        <td><?php echo e($proparty->admin_fee_exe); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Admin Fee Flag :</th>
                                        <td><?php echo e(($proparty->admin_fee_flag) ? 'Yes' : 'No'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Date Intake :</th>
                                        <td><?php echo e($proparty->date_intake); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Date Published :</th>
                                        <td><dd><?php echo e($proparty->date_published); ?></dd></td>
                                    </tr>
                                    <tr>
                                        <th>Date Revoked :</th>
                                        <td><?php echo e($proparty->date_revoked); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Property Details :</th>
                                        <td><?php echo e($proparty->property_details); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Further Details :</th>
                                        <td><?php echo e(implode(', ', $proparty->further_details)); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Property Details Display :</th>
                                        <td><?php echo e(($proparty->property_details_display) ? 'Yes' : 'No'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Owner :</th>
                                        <td><?php echo e(optional($proparty->ownerman)->name); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Is Complete  :</th>
                                        <td><?php echo e(($proparty->is_complete) ? 'Yes' : 'No'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Is Publish  :</th>
                                        <td><?php echo e(($proparty->is_publish) ? 'Yes' : 'No'); ?></td>
                                    </tr>
                                    <tr>
                                        <th colspan="2" style="color:#FF4500"><h1>Owner Details</h1></th>
                                    </tr>
                                    <tr>
                                        <th>Owner Name:</th>
                                        <td><?php echo e(optional($proparty->ownerman)->name); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Contact No:</th>
                                        <td><?php echo e(optional($proparty->ownerman)->contact_no); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Email:</th>
                                        <td><?php echo e(optional($proparty->ownerman)->email); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Address:</th>
                                        <td><?php echo e(optional($proparty->ownerman)->address); ?></td>
                                    </tr>  
                                </table>
                            </div>
                            <div class="table-responsive">
                                <table class="table">
                                    <tr>
                                        <th colspan="6" style="color:#FF4500"><h1>Room Details</h1></th>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th>No</th>
                                        <th>Room Name</th>
                                        <th>Room Length</th>
                                        <th>Room Width</th>
                                        <th>Room Dimention display</th>
                                        <th>Property Id</th>
                                    </tr>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($room->room_name); ?></td>
                                        <td><?php echo e($room->room_length); ?> <?php echo e($room->room_dimention_unit); ?></td>
                                        <td><?php echo e($room->room_width); ?> <?php echo e($room->room_dimention_unit); ?></td>
                                        <td><?php echo e($room->room_dimention_display); ?> <?php echo e($room->room_area_unit); ?></td>
                                        <td><?php echo e($room->property_id); ?></td>
                                    </tr>
                                    <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                            
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\realproperty\real_property\resources\views/proparties/show.blade.php ENDPATH**/ ?>