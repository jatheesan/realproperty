
<?php $__env->startSection('pagetitle', 'Properties'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-sm-12">
            <?php if(Session::has('success_message')): ?>
            <div class="alert alert-success">
                <span class="glyphicon glyphicon-ok"></span>
                <?php echo session('success_message'); ?>


                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
            <?php endif; ?>
        </div>
        <!-- Area Chart -->
        <div class="col-xl-12 col-lg-12 col-sm-12">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    
                    <div class="col-xl-12 col-lg-12 col-sm-12">

                    <div class="float-right p-2">
                        <div class="btn-group btn-group-sm pull-right" role="group">
                            <form action="<?php echo e(route('proparties.proparty.uncompletesearch')); ?>">
                                <input type="hidden" name="search_pro" value="sold">
                                <button type="submit" class="btn btn-sm btn-warning" title="search uncomplete proparty">sold</button>
                            </form>
                        </div>
                    </div>
                    <div class="float-right p-2">
                        <div class="btn-group btn-group-sm pull-right" role="group">
                            <form action="<?php echo e(route('proparties.proparty.uncompletesearch')); ?>">
                                <input type="hidden" name="search_pro" value="unpublish">
                                <button type="submit" class="btn btn-sm btn-primary" title="search uncomplete proparty">unpublish</button>
                            </form>
                        </div>
                    </div>
                    <div class="float-right p-2">
                        <div class="btn-group btn-group-sm pull-right" role="group">
                            <form action="<?php echo e(route('proparties.proparty.uncompletesearch')); ?>">
                                <input type="hidden" name="search_pro" value="uncomplete">
                                <button type="submit" class="btn btn-sm btn-info" title="search uncomplete proparty">uncomplete</button>
                            </form>
                        </div>
                    </div>
                    <div class="float-right p-2">
                        <div class="btn-group btn-group-sm pull-right" role="group">
                            <a href="<?php echo e(route('proparties.proparty.create')); ?>" class="btn btn-success"
                                title="Create New Proparty">
                                <span class="fa fa-plus" aria-hidden="true"></span>
                            </a>
                        </div>
                    </div>
                    </div>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="panel panel-default">
                        <?php if(count($proparties) == 0): ?>
                            <div class="panel-body text-center">
                                <h4>No Proparties Available.</h4>
                            </div>
                        <?php else: ?>
                        <div class="panel-body panel-body-with-table">
                            <div class="table-responsive">

                                <table class="table table-striped ">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Actions</th>
                                            <th>Catagery</th>
                                            <th>Property Type</th>
                                            <th>Property Age</th>
                                            
                                            <th>Display Address</th>
                                            
                                            <th>No of Bedrooms</th>
                                            <th>No of Bathrooms</th>
                                            <th>No of Halls</th>
                                            <th>No of Reseptions</th>
                                            <th>Floors</th>
                                            
                                            <th>Price</th>
                                            
                                            <th>Owner</th>
                                            <th>Is Complete</th>
                                            <th>Is Publish</th>
                                            <th>Is Sold</th>
                                            <th>Room</th>
                                            <th>Owner</th>
                                            <th>Images</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $proparties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proparty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td>
                                                <form method="POST" action="<?php echo route('proparties.proparty.destroy', $proparty->id); ?>" accept-charset="UTF-8">
                                                <input name="_method" value="DELETE" type="hidden">
                                                <?php echo e(csrf_field()); ?>


                                                    <div class="btn-group btn-group-xs pull-right" role="group">
                                                        <a href="<?php echo e(route('proparties.proparty.show', $proparty->id )); ?>" class="btn btn-info" title="Show Proparty">
                                                            <i class="fa fa-list-ul" aria-hidden="true"></i>
                                                        </a>
                                                        <a href="<?php echo e(route('proparties.proparty.edit', $proparty->id )); ?>" class="btn btn-primary" title="Edit Proparty">
                                                            <span class="fa fa-pencil-alt" aria-hidden="true"></span>
                                                        </a>

                                                        <button type="submit" class="btn btn-danger" title="Delete Proparty" onclick="return confirm(&quot;Click Ok to delete Proparty.&quot;)">
                                                            <span class="fa fa-trash" aria-hidden="true"></span>
                                                        </button>
                                                    </div>

                                                </form>
                                            </td>
                                            <td><?php echo e($proparty->catagery); ?></td>
                                            <td><?php echo e(optional($proparty->propertytype)->type_name); ?></td>
                                            <td><?php echo e($proparty->age); ?></td>
                                            
                                            <td><?php echo e($proparty->display_address); ?></td>
                                            
                                            <td><?php echo e($proparty->no_of_bedrooms); ?></td>
                                            <td><?php echo e($proparty->no_of_bathrooms); ?></td>
                                            <td><?php echo e($proparty->no_of_halls); ?></td>
                                            <td><?php echo e($proparty->no_of_reseptions); ?></td>
                                            <td><?php echo e($proparty->floors); ?></td>
                                            
                                            <td><?php echo e($proparty->price); ?></td>
                                            
                                            <td><?php echo e($proparty->owner); ?></td>
                                            <td><?php echo e(($proparty->is_complete) ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e(($proparty->is_publish) ? 'Yes' : 'No'); ?></td>
                                            <td> 
                                                <?php if(($proparty->is_sold) == 1): ?>
                                                    
                                                    
                                                    <div style="color:orange"><?php echo e(($proparty->is_sold) ? 'Yes' : 'No'); ?></div>
                                                <?php else: ?>
                                                    
                                                    <div style="color:red"><?php echo e(($proparty->is_sold) ? 'Yes' : 'No'); ?></div>
                                                <?php endif; ?>
                                                
                                            <td>
                                                <form action="<?php echo e(route('rooms.room.multicreate')); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                    <input type="hidden" name="id" value="<?php echo e($proparty->id); ?>">

                                                    <input type="submit" class="btn btn-success" value="Add room">
                                                </form>
                                            </td>
                                            <td>
                                                <form action="<?php echo e(route('owners.owner.ownercreate')); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                    <input type="hidden" name="id" value="<?php echo e($proparty->id); ?>">

                                                    <input type="submit" class="btn btn-success" value="Add owner">
                                                </form>
                                                
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('image.create', $proparty->id )); ?>" class="btn btn-success" title="Add images">Add Images</a>
                                            </td>

                                            
                                        </tr>
                                    <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>

                        <div class="panel-footer">
                            <?php echo $proparties->render("pagination::bootstrap-4"); ?>

                        </div>
                        
                        <?php endif; ?>
                    
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<!-- Modal -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\realproperty\real_property\resources\views/proparties/index.blade.php ENDPATH**/ ?>