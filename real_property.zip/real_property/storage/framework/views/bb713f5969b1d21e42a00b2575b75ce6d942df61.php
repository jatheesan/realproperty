

<?php $__env->startSection('content'); ?>
<main id="main">

    <!-- ======= Intro Single ======= -->


    <!-- ======= Property Single ======= -->
    <section class="property-single nav-arrow-b">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                        <div id="property-single-carousel" class="owl-carousel owl-arrow gallery-property popup-gallery">
                            <?php $__currentLoopData = $property->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item-b">
                                    <a data-toggle="modal" data-target="#GListModalGallery"><img src="<?php echo e(asset($image->image)); ?>" class="property-image" alt="" /></a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                </div>
                <div class="col-sm-12">
                    <!-- modalGallery -->
                    <div class="modal" id="GListModalGallery" tabindex="-1" role="dialog" aria-labelledby="GListModalGalleryLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal"><span
                                            aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                </div>
                                <div class="modal-body">
                                    <div id="owl-modal">
                                        <div class="item"><img src="<?php echo e(asset('images/single-property/single-prop-1.jpeg')); ?>" alt="" /></div>
                                        <div class="item"><img src="<?php echo e(asset('images/single-property/single-prop-3.jpeg')); ?>" alt="" /></div>
                                        <div class="item"><img src="<?php echo e(asset('images/single-property/single-prop-5.jpeg')); ?>" alt="" /></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /modalGallery -->
                </div>
            </div>
            
        </div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="row justify-content-between">
                        <div class="col-md-5 col-lg-4">
                            <div class="property-price d-flex justify-content-center foo">
                                <div class="card-header-c d-flex">
                                <?php if(isset($property->price)): ?>
                                    <div class="card-box-ico">
                                            <span class="ion-money">£</span>
                                    </div>
                                    <div class="card-title-c align-self-center">
                                        <h5 class="title-c"><?php echo e($property->price); ?></h5>
                                    </div>
                                <?php else: ?>
                                    <div class="card-box-ico1">
                                        <span class="ion-money">Call for Price</span>
                                    </div>
                                <?php endif; ?>
                                </div>
                            </div>
                            <div class="property-summary">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="section-t4">
                                            <h3 class="title-e">Quick Summary</h3><hr/>
                                        </div>
                                    </div>
                                </div>
                                <div class="summary-list">
                                    <ul class="list">
                                        <?php if(isset($property->display_address)): ?>
                                        <li class="d-flex justify-content-between">
                                            <strong>Location:</strong>
                                            <span> <?php echo nl2br($property->display_address) ?></span>
                                        </li>
                                        <?php endif; ?>
                                        <?php if(isset($property->type)): ?>
                                        <li class="d-flex justify-content-between">
                                            <strong>Property Type :</strong>
                                            <span><?php echo e(optional($property->propertytype)->type_name); ?></span>
                                        </li>
                                        <?php endif; ?>
                                        <?php if(isset($property->catagery)): ?>
                                            <li class="d-flex justify-content-between">
                                                <strong>Status :</strong>
                                                <?php if(($property->catagery) == 'for sale'): ?>
                                                    <span>sale</span>
                                                <?php else: ?>
                                                    <span>Rent | <?php echo e($property->rent_frequency); ?></span>
                                                <?php endif; ?>
                                            </li>
                                        <?php endif; ?>
                                        <?php if(isset($property->land_area)): ?>
                                        <li class="d-flex justify-content-between">
                                            <strong>Land Area :</strong>
                                            <span><?php echo e($property->land_area); ?><?php echo e(' '); ?><?php echo e($property->area_unit); ?></span>
                                        </li>
                                        <?php endif; ?>
                                        <?php if(isset($property->internal_area)): ?>
                                        <li class="d-flex justify-content-between">
                                            <strong>Internal Area :</strong>
                                            <span><?php echo e($property->internal_area); ?><?php echo e(' '); ?><?php echo e($property->area_unit); ?></span>
                                        </li>
                                        <?php endif; ?>
                                        <?php if(isset($property->no_of_bedrooms)): ?>
                                        <li class="d-flex justify-content-between">
                                            <strong>Bedrooms :</strong>
                                            <span><?php echo e($property->no_of_bedrooms); ?></span>
                                        </li>
                                        <?php endif; ?>
                                        <?php if(isset($property->no_of_bathrooms)): ?>
                                        <li class="d-flex justify-content-between">
                                            <strong>Bathrooms :</strong>
                                            <span><?php echo e($property->no_of_bathrooms); ?></span>
                                        </li>
                                        <?php endif; ?>
                                        <?php if(isset($property->no_of_halls)): ?>
                                        <li class="d-flex justify-content-between">
                                            <strong>Halls :</strong>
                                            <span><?php echo e($property->no_of_halls); ?></span>
                                        </li>
                                        <?php endif; ?>
                                        <?php if(isset($property->no_of_reseptions)): ?>
                                        <li class="d-flex justify-content-between">
                                            <strong>Reseptions:</strong>
                                            <span><?php echo e($property->no_of_reseptions); ?></span>
                                        </li>
                                        <?php endif; ?>
                                        <?php if(isset($property->parking)): ?>
                                        <li class="d-flex justify-content-between">
                                            <strong>Parking :</strong>
                                            <span><?php echo e(implode(' & ', $property->parking)); ?></span>
                                        </li>
                                        <?php endif; ?>
                                        <?php if(isset($property->garden)): ?>
                                        <li class="d-flex justify-content-between">
                                            <strong>Garden :</strong>
                                            <span><?php echo e(implode(' & ', $property->garden)); ?></span>
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-7 col-lg-7 section-md-t3">
                            <?php if(isset($property->property_details)): ?>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div>
                                        <h3 class="title-e">About this property</h3><hr/>
                                    </div>
                                </div>
                            </div>
                            <div class="property-description">
                                <p class="description color-text-a" style="text-align: justify;">
                                    <?php echo nl2br($property->property_details) ?>
                                </p>
                            </div>
                            <?php endif; ?>
                            <?php if(isset($property->property_details) || isset($property->further_details)): ?>
                            <div class="row section-t3">
                                <div class="col-sm-12">
                                    <div>
                                        <h3 class="title-e">Further Details</h3><hr/>
                                    </div>
                                </div>
                            </div>
                            <div class="amenities-list color-text-a">
                                <ul class="list-a no-margin">
                                    <?php if(isset($property->further_details)): ?>
                                        <?php $__currentLoopData = $property->further_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($key != null): ?>
                                                <li><?php echo e($key); ?></li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <?php if(isset($property->is_burglar_alarm)): ?>
                                        <?php if(($property->is_burglar_alarm) == 1): ?>
                                            <li><?php echo e('Having barglar alarm feature'); ?></li>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if(isset($property->is_cctv)): ?>
                                        <?php if(($property->is_cctv) == 1): ?>
                                            <li><?php echo e('Having CCTV feature'); ?></li>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-12">
                    <div class="row section-t3">
                        <div class="col-sm-12">
                            <div>
                                <h3 class="title-e">Contact Agent</h3><hr/>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        
                        <div class="col-md-6 col-lg-4">
                            <div class="property-agent">
                                <br>
                                <h4 class="title-agent">Anabella Geller</h4>
                                <p class="color-text-a">
                                    Nulla porttitor accumsan tincidunt. Vestibulum ac diam sit amet quam vehicula
                                    elementum sed sit amet
                                    dui. Quisque velit nisi,
                                    pretium ut lacinia in, elementum id enim.
                                </p>
                                <ul class="list-unstyled">
                                    
                                    <li class="d-flex justify-content-between">
                                        <strong>Email:</strong>
                                        <span class="color-text-a">annabella@example.com</span>
                                    </li>
                                    <li class="d-flex justify-content-between">
                                        <strong>Skype:</strong>
                                        <span class="color-text-a">Annabela.ge</span>
                                    </li>
                                </ul>
                                <div class="socials-a">
                                    <ul class="list-inline">
                                        <li class="list-inline-item">
                                            <a href="#">
                                                <i class="fa fa-facebook" aria-hidden="true"></i>
                                            </a>
                                        </li>
                                        <li class="list-inline-item">
                                            <a href="#">
                                                <i class="fa fa-twitter" aria-hidden="true"></i>
                                            </a>
                                        </li>
                                        <li class="list-inline-item">
                                            <a href="#">
                                                <i class="fa fa-instagram" aria-hidden="true"></i>
                                            </a>
                                        </li>
                                        <li class="list-inline-item">
                                            <a href="#">
                                                <i class="fa fa-pinterest-p" aria-hidden="true"></i>
                                            </a>
                                        </li>
                                        <li class="list-inline-item">
                                            <a href="#">
                                                <i class="fa fa-dribbble" aria-hidden="true"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-8">
                            <div class="property-contact">
                                <form class="form-a">
                                    <div class="row">
                                        <div class="col-md-12 col-lg-6 mb-1">
                                            <div class="form-group">
                                                <input type="text" class="form-control form-control-lg form-control-a"
                                                    id="inputName" placeholder="Name *" required>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-lg-6 mb-1">
                                            <div class="form-group">
                                                <input type="email" class="form-control form-control-lg form-control-a"
                                                    id="inputEmail1" placeholder="Email *" required>
                                            </div>
                                        </div>
                                        <div class="col-md-12 mb-1">
                                            <div class="form-group">
                                                <textarea id="textMessage" class="form-control" placeholder="Comment *"
                                                    name="message" cols="45" rows="8" required></textarea>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <button type="submit" class="btn btn-a">Send Message</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- End Property Single-->

</main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.applayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\realproperty\real_property\resources\views/pages/single-property.blade.php ENDPATH**/ ?>