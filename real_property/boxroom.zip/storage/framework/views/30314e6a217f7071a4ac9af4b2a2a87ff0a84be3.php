
<?php $__env->startSection('pagetitle', 'Properties'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <!-- Area Chart -->
        <div class="col-xl-12 col-lg-12 col-sm-12">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    
                    <div class="col-xl-11 col-lg-11 col-sm-11">
                    <?php if(Session::has('success_message')): ?>
                        <div class="alert alert-success">
                            <span class="glyphicon glyphicon-ok"></span>
                            <?php echo session('success_message'); ?>


                            <button type="button" class="close" data-dismiss="alert" aria-label="close">
                                <span aria-hidden="true">&times;</span>
                            </button>

                        </div>
                    <?php endif; ?>
                    </div>
                    <div class="float-right">
                        <div class="btn-group btn-group-sm pull-right" role="group">
                            <a href="<?php echo e(route('proparties.proparty.create')); ?>" class="btn btn-success"
                                title="Create New Proparty">
                                <span class="fa fa-plus" aria-hidden="true"></span>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="panel panel-default">
                        <?php if(count($proparties) == 0): ?>
                            <div class="panel-body text-center">
                                <h4>No Proparties Available.</h4>
                            </div>
                        <?php else: ?>
                        <div class="panel-body panel-body-with-table">
                            <div class="table-responsive">

                                <table class="table table-striped ">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Actions</th>
                                            <th>Catagery</th>
                                            <th>Property Type</th>
                                            <th>Property Age</th>
                                            <th>Minimum Term</th>
                                            <th>Door No</th>
                                            <th>Door Name</th>
                                            <th>First Postcode</th>
                                            <th>Second Postcode</th>
                                            <th>Post Town</th>
                                            <th>Post City</th>
                                            <th>Post Country</th>
                                            <th>Display Address</th>
                                            <th>Condition of Property</th>
                                            <th>Furnished Property</th>
                                            <th>Accessability</th>
                                            <th>Heating Type</th>
                                            <th>Is Burglar Alarm</th>
                                            <th>Is CCTV</th>
                                            <th>Bill</th>
                                            <th>Property Enquiry Contact</th>
                                            <th>Property Enquiry Email</th>
                                            <th>Sale Condition</th>
                                            <th>Rent Condition</th>
                                            <th>Property Details</th>
                                            <th>Property Details Display</th>
                                            <th>NO of Bedrooms</th>
                                            <th>NO of Halls</th>
                                            <th>NO of Reseptions</th>
                                            <th>Floors</th>
                                            <th>Parking</th>
                                            <th>Garden</th>
                                            <th>Internal Area</th>
                                            <th>Land Area</th>
                                            <th>Price</th>
                                            <th>Price Flag</th>
                                            <th>Rent Frequency</th>
                                            <th>Deposite Minimum</th>
                                            <th>Deposite Flag</th>
                                            <th>Admin Fee Maxmimum</th>
                                            <th>Admin Fee Exemption</th>
                                            <th>Admin Fee Flag</th>
                                            <th>date Intake</th>
                                            <th>date Published</th>
                                            <th>date Revoked</th>
                                            <th>Owner</th>
                                            <th>Is Publish</th>
                                            <th>Room</th>
                                            <th>Owner</th>
                                            <th>Images</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $proparties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proparty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td>
                                                <form method="POST" action="<?php echo route('proparties.proparty.destroy', $proparty->id); ?>" accept-charset="UTF-8">
                                                <input name="_method" value="DELETE" type="hidden">
                                                <?php echo e(csrf_field()); ?>


                                                    <div class="btn-group btn-group-xs pull-right" role="group">
                                                        <a href="<?php echo e(route('proparties.proparty.show', $proparty->id )); ?>" class="btn btn-info" title="Show Proparty">
                                                            <span class="fa fa-caret-square-o-up" aria-hidden="true"></span>
                                                        </a>
                                                        <a href="<?php echo e(route('proparties.proparty.edit', $proparty->id )); ?>" class="btn btn-primary" title="Edit Proparty">
                                                            <span class="fa fa-pencil-alt" aria-hidden="true"></span>
                                                        </a>

                                                        <button type="submit" class="btn btn-danger" title="Delete Proparty" onclick="return confirm(&quot;Click Ok to delete Proparty.&quot;)">
                                                            <span class="fa fa-trash" aria-hidden="true"></span>
                                                        </button>
                                                    </div>

                                                </form>
                                            </td>
                                            <td><?php echo e($proparty->catagery); ?></td>
                                            <td><?php echo e(optional($proparty->propertytype)->type_name); ?></td>
                                            <td><?php echo e($proparty->age); ?></td>
                                            <td><?php echo e($proparty->minimum_term); ?></td>
                                            <td><?php echo e($proparty->door_no); ?></td>
                                            <td><?php echo e($proparty->door_name); ?></td>
                                            <td><?php echo e($proparty->first_pastcode); ?></td>
                                            <td><?php echo e($proparty->second_pastcode); ?></td>
                                            <td><?php echo e($proparty->post_town); ?></td>
                                            <td><?php echo e($proparty->post_city); ?></td>
                                            <td><?php echo e($proparty->post_country); ?></td>
                                            <td><?php echo e($proparty->display_address); ?></td>
                                            <td><?php echo e($proparty->condition_of_property); ?></td>
                                            <td><?php echo e(implode(', ', $proparty->furnished_property)); ?></td>
                                            <td><?php echo e(implode(', ', $proparty->accessability)); ?></td>
                                            <td><?php echo e(implode(', ', $proparty->heating_type)); ?></td>
                                            <td><?php echo e(($proparty->is_burglar_alarm) ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e(($proparty->is_cctv) ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($proparty->bill); ?></td>
                                            <td><?php echo e($proparty->enquiry_contact); ?></td>
                                            <td><?php echo e($proparty->enquiry_email); ?></td>
                                            <td><?php echo e($proparty->sale_condition); ?></td>
                                            <td><?php echo e($proparty->rent_condition); ?></td>
                                            <td><?php echo e($proparty->property_details); ?></td>
                                            <td><?php echo e($proparty->property_details_display); ?></td>
                                            <td><?php echo e($proparty->no_of_bedrooms); ?></td>
                                            <td><?php echo e($proparty->no_of_halls); ?></td>
                                            <td><?php echo e($proparty->no_of_reseptions); ?></td>
                                            <td><?php echo e($proparty->floors); ?></td>
                                            <td><?php echo e(implode(', ', $proparty->parking)); ?></td>
                                            <td><?php echo e(implode(', ', $proparty->garden)); ?></td>
                                            <td><?php echo e($proparty->internal_area); ?></td>
                                            <td><?php echo e($proparty->land_area); ?></td>
                                            <td><?php echo e($proparty->price); ?></td>
                                            <td><?php echo e(($proparty->price_flag) ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($proparty->rent_frequency); ?></td>
                                            <td><?php echo e($proparty->deposite); ?></td>
                                            <td><?php echo e(($proparty->deposite_flag) ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($proparty->admin_fee_max); ?></td>
                                            <td><?php echo e($proparty->admin_fee_exe); ?></td>
                                            <td><?php echo e(($proparty->admin_fee_flag) ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($proparty->date_intake); ?></td>
                                            <td><?php echo e($proparty->date_published); ?></td>
                                            <td><?php echo e($proparty->date_revoked); ?></td>
                                            <td><?php echo e($proparty->owner); ?></td>
                                            <td><?php echo e(($proparty->is_publish) ? 'Yes' : 'No'); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('rooms.room.multicreate')); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                    <input type="hidden" name="id" value="<?php echo e($proparty->id); ?>">

                                                    <input type="submit" class="btn btn-success" value="Add room">
                                                </form>
                                            </td>
                                            <td>
                                                <form action="<?php echo e(route('owners.owner.ownercreate')); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                    <input type="hidden" name="id" value="<?php echo e($proparty->id); ?>">

                                                    <input type="submit" class="btn btn-success" value="Add owner">
                                                </form>
                                                
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('image.create', $proparty->id )); ?>" class="btn btn-success" title="Add images">Add Images</a>
                                            </td>

                                            
                                        </tr>
                                    <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>

                        <div class="panel-footer">
                            <?php echo $proparties->render("pagination::bootstrap-4"); ?>

                        </div>
                        
                        <?php endif; ?>
                    
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- Modal -->

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\realproperty\real_property\resources\views/proparties/index.blade.php ENDPATH**/ ?>