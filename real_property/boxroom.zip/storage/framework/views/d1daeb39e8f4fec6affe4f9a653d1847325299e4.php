<!-- Forget Password-->
<div class="modal" id="forgetpasswordModal" tabindex="-1" role="dialog" aria-labelledby="forgetpasswordModal" aria-hidden="true">
    <div class="container">
        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">
                <button type="button" onclick="javascript:window.location.reload()" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block" style="background-image: url('<?php echo e(asset('images/properties/prop-9.jpg')); ?>');"></div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-2">Forgot Your Password?</h1>
                                        <p class="mb-4">We get it, stuff happens. Just enter your email address
                                            below
                                            and we'll send you a link to reset your password!</p>
                                    </div>
                                    <?php if(session('status')): ?>
                                        <div class="alert alert-success" role="alert">
                                            <?php echo e(session('status')); ?>

                                        </div>
                                    <?php endif; ?>
                                    <form class="user" method="POST" action="<?php echo e(route('password.email')); ?>">
                                    <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <input id="email" type="email" class="form-control form-control-user <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Enter Email Address...">

                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <button type="submit" class="btn btn-org btn-user btn-block">
                                            <?php echo e(__('Send Password Reset Link')); ?>

                                        </button>
                                    </form>
                                    <hr style="border-top: 1px solid #6c757d !important;">
                                    <div class="text-center">
                                        <a href="" class="small color-b" data-dismiss="modal" data-toggle="modal"
                                            data-target="#registerModal"><?php echo e(__('Create an Account!')); ?></a>
                                    </div>
                                    <div class="text-center">
                                        <a href="" class="small color-b" data-dismiss="modal" data-toggle="modal"
                                            data-target="#loginModal"><?php echo e(__('Already have an account? Login!')); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##

<?php if(session('status')): ?>
    <script>
    $(function() {
        $('#forgetpasswordModal').modal({
            show: true
        });
    });
    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\laravel\realproperty\real_property\resources\views/partials/forgetpassword.blade.php ENDPATH**/ ?>