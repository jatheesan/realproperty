
<?php $__env->startSection('pagetitle', 'Property Images'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xl-12 col-lg-12">
        <div class="float-right">
            <div class="btn-group btn-group-sm pull-right" role="group">
                <a href="<?php echo e(route('image')); ?>" class="btn btn-primary" title="Show All Images">
                    <span class="fa fa-th-list" aria-hidden="true"></span>
                </a>
            </div>
        </div>
    </div>
    <div class="col-xl-12 col-lg-12">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <div class="col-xl-12 col-lg-12">
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <span class="fa fa-ok"></span>
                        <?php echo session('success'); ?>


                        <button type="button" class="close" data-dismiss="alert" aria-label="close">
                            <span aria-hidden="true">&times;</span>
                        </button>

                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <div class="panel panel-default">
                    <div class="panel-body panel-body-with-table">
                        <div class="row">
                            <div class="col-md-9">
                                <div class="card-group">
                                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $multi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 mt-5">
                                        <div class="card">
                                            <img src="<?php echo e(asset($multi->image)); ?>" alt="">
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 mt-5">
                                <div class="card">
                                    <div class="card-header">
                                        Adding images for property <?php echo e($pro_id); ?>

                                    </div>
                                    <div class="card-body">
                                        <form action="<?php echo e(route('image.store')); ?>" method="POST"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <input class="form-control form-control-user" name="property_id" type="hidden"
                                                    id="property_id" value="<?php echo e($pro_id); ?>" min="0" max="4294967295"
                                                    required="true">
                                                <label for="">Propety Image</label>
                                                <input type="file" name="image[]" class="form-control form-control-user" multiple="">
                                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <button type="submit" class="btn btn-org">Add Image</button>
                                        </form>

                                    </div>
                                </div>

                                <div class="card mt-5">
                                    <div class="card-header">
                                        Update main image for property <?php echo e($pro_id); ?>

                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <?php if(isset($main)): ?>
                                                <div class="card">
                                                    <img src="<?php echo e(asset($main->image)); ?>" alt="">
                                                </div>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $multi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-xs-3 mb-3 ml-3">
                                                

                                                <form action="<?php echo e(route('image.update', $multi->id)); ?>" method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                    <input class="form-control form-control-user" name="property_id" type="hidden"
                                                    id="property_id" value="<?php echo e($pro_id); ?>" min="0" max="4294967295"
                                                    required="true">
                                                    <button type="submit"><img src="<?php echo e(asset($multi->image)); ?>" width="50px" height= "40px"></button>
                                                </form>
                                                
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="card mt-5">
                                    <div class="card-header">
                                        Delete property <?php echo e($pro_id); ?>'s image
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $multi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-xs-3 mb-3 ml-3">

                                                <form action="<?php echo e(route('image.delete', $multi->id)); ?>" method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                    <button type="submit"><img src="<?php echo e(asset($multi->image)); ?>" width="50px" height= "40px"></button>
                                                </form>
                                                
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\realproperty\real_property\resources\views/images/index.blade.php ENDPATH**/ ?>